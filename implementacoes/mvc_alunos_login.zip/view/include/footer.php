
<footer class="bg-light text-muted mt-3">
    <div class="text-center p-4">
        © 2026 Copyright:
        <a href="https://foz.ifpr.edu.br"
        target="blank">IFPR (Campus Foz do Iguaçu)</a>
    </div>
</footer>


<!-- Fecha a tag div do container aberta no arquivo header.php -->
</div>

<!-- Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

</body>
</html>